from fastapi import FastAPI, APIRouter, Depends, HTTPException, Header
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import uuid
import secrets
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import datetime, timezone, timedelta

import bcrypt
import jwt
import httpx

from seed_data import (
    UNIVERSITIES, COURSES, OPPORTUNITIES, SCHOLARSHIPS,
    INTEREST_CHIPS, COURSE_CHIPS, COUNTRY_CHIPS,
)

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

JWT_SECRET = os.environ['JWT_SECRET']
JWT_ALGO = "HS256"
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')
EMERGENT_OAUTH_URL = "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data"

app = FastAPI()
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("ryze")


# ----------------------------- Helpers -----------------------------
def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def new_id(prefix: str = "") -> str:
    return f"{prefix}{uuid.uuid4().hex[:16]}"


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode(), hashed.encode())
    except Exception:
        return False


def make_jwt(user_id: str) -> str:
    payload = {"user_id": user_id, "iat": now_utc(), "exp": now_utc() + timedelta(days=30)}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGO)


def clean(doc: dict) -> dict:
    if doc:
        doc.pop("_id", None)
    return doc


# ----------------------------- Models -----------------------------
class RegisterInput(BaseModel):
    name: str
    email: EmailStr
    password: str
    date_of_birth: Optional[str] = None


class LoginInput(BaseModel):
    email: EmailStr
    password: str


class SessionInput(BaseModel):
    session_id: str


class ForgotInput(BaseModel):
    email: EmailStr


class ResetInput(BaseModel):
    token: str
    new_password: str


class ProfileInput(BaseModel):
    display_name: Optional[str] = None
    school_year: Optional[str] = None
    grade_average: Optional[float] = None
    curriculum: Optional[str] = None
    interests: Optional[List[str]] = None
    target_courses: Optional[List[str]] = None
    preferred_countries: Optional[List[str]] = None
    activities: Optional[List[str]] = None
    budget: Optional[float] = None
    target_universities: Optional[List[str]] = None
    reminders_enabled: Optional[bool] = None


class SavedInput(BaseModel):
    item_type: str
    item_id: str


class ApplicationInput(BaseModel):
    title: str
    item_type: str = "custom"
    item_id: Optional[str] = None
    deadline: Optional[str] = None
    next_step: Optional[str] = None
    status: str = "Planning"


class ApplicationUpdate(BaseModel):
    status: Optional[str] = None
    next_step: Optional[str] = None
    deadline: Optional[str] = None


# ----------------------------- Auth -----------------------------
async def get_current_user(authorization: Optional[str] = Header(None)) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = authorization.split(" ", 1)[1].strip()

    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGO])
        user = await db.users.find_one({"user_id": payload["user_id"]}, {"_id": 0})
        if user:
            return user
    except jwt.PyJWTError:
        pass

    session = await db.user_sessions.find_one({"session_token": token}, {"_id": 0})
    if session:
        expires_at = session.get("expires_at")
        if isinstance(expires_at, datetime):
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
            if expires_at > now_utc():
                user = await db.users.find_one({"user_id": session["user_id"]}, {"_id": 0})
                if user:
                    return user
    raise HTTPException(status_code=401, detail="Invalid or expired token")


def user_public(user: dict) -> dict:
    return {
        "user_id": user["user_id"],
        "name": user.get("name"),
        "email": user.get("email"),
        "picture": user.get("picture"),
        "date_of_birth": user.get("date_of_birth"),
    }


@api_router.post("/auth/register")
async def register(inp: RegisterInput):
    existing = await db.users.find_one({"email": inp.email.lower()})
    if existing:
        raise HTTPException(status_code=400, detail="An account with this email already exists")
    user = {
        "user_id": new_id("user_"),
        "name": inp.name,
        "email": inp.email.lower(),
        "password_hash": hash_password(inp.password),
        "date_of_birth": inp.date_of_birth,
        "picture": None,
        "auth_provider": "email",
        "created_at": now_utc().isoformat(),
    }
    await db.users.insert_one(dict(user))
    await ensure_profile(user["user_id"], inp.name)
    return {"token": make_jwt(user["user_id"]), "user": user_public(user)}


@api_router.post("/auth/login")
async def login(inp: LoginInput):
    user = await db.users.find_one({"email": inp.email.lower()}, {"_id": 0})
    if not user or not user.get("password_hash") or not verify_password(inp.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return {"token": make_jwt(user["user_id"]), "user": user_public(user)}


@api_router.post("/auth/forgot-password")
async def forgot_password(inp: ForgotInput):
    user = await db.users.find_one({"email": inp.email.lower()})
    if not user:
        return {"message": "If an account exists, a reset link has been sent."}
    token = secrets.token_urlsafe(24)
    await db.password_resets.insert_one({
        "token": token, "user_id": user["user_id"],
        "expires_at": (now_utc() + timedelta(hours=1)).isoformat(),
    })
    return {"message": "Reset link generated.", "reset_token": token}


@api_router.post("/auth/reset-password")
async def reset_password(inp: ResetInput):
    rec = await db.password_resets.find_one({"token": inp.token})
    if not rec:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token")
    exp = datetime.fromisoformat(rec["expires_at"])
    if exp.tzinfo is None:
        exp = exp.replace(tzinfo=timezone.utc)
    if exp < now_utc():
        raise HTTPException(status_code=400, detail="Reset token has expired")
    await db.users.update_one({"user_id": rec["user_id"]}, {"$set": {"password_hash": hash_password(inp.new_password)}})
    await db.password_resets.delete_one({"token": inp.token})
    return {"message": "Password updated successfully."}


@api_router.post("/auth/session")
async def google_session(inp: SessionInput):
    async with httpx.AsyncClient(timeout=20) as hc:
        resp = await hc.get(EMERGENT_OAUTH_URL, headers={"X-Session-ID": inp.session_id})
    if resp.status_code != 200:
        raise HTTPException(status_code=401, detail="Invalid session")
    data = resp.json()
    email = data.get("email", "").lower()
    name = data.get("name")
    picture = data.get("picture")
    session_token = data.get("session_token")

    user = await db.users.find_one({"email": email}, {"_id": 0})
    if not user:
        user = {
            "user_id": new_id("user_"),
            "name": name, "email": email, "picture": picture,
            "password_hash": None, "date_of_birth": None,
            "auth_provider": "google", "created_at": now_utc().isoformat(),
        }
        await db.users.insert_one(dict(user))
        await ensure_profile(user["user_id"], name)

    await db.user_sessions.insert_one({
        "session_token": session_token,
        "user_id": user["user_id"],
        "created_at": now_utc(),
        "expires_at": now_utc() + timedelta(days=7),
    })
    return {"session_token": session_token, "token": session_token, "user": user_public(user)}


@api_router.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return {"user": user_public(user)}


# ----------------------------- Profile -----------------------------
def compute_strength(p: dict) -> int:
    score = 0
    if p.get("grade_average"):
        score += 15
    if p.get("curriculum"):
        score += 10
    if len(p.get("interests") or []) >= 3:
        score += 15
    elif p.get("interests"):
        score += 7
    if p.get("target_courses"):
        score += 15
    if p.get("preferred_countries"):
        score += 10
    acts = p.get("activities") or []
    score += min(len(acts) * 5, 20)
    if p.get("budget"):
        score += 5
    if p.get("target_universities"):
        score += 10
    score += min((p.get("roadmap_done") or 0) * 3, 15)
    return min(score, 100)


def compute_categories(p: dict) -> dict:
    acts = [a.lower() for a in (p.get("activities") or [])]
    grade = p.get("grade_average") or 0
    academics = min(int(grade), 100) if grade else 40

    def count(keys):
        return sum(1 for a in acts if any(k in a for k in keys))

    projects = min(40 + count(["project", "build", "app"]) * 25, 100)
    competitions = min(30 + count(["competition", "hackathon", "olympiad", "contest", "award"]) * 25, 100)
    experience = min(30 + count(["intern", "research", "work", "job", "volunteer"]) * 25, 100)
    leadership = min(30 + count(["lead", "president", "captain", "founder", "club", "head", "organiz"]) * 25, 100)
    return {
        "academics": academics,
        "projects": projects,
        "competitions": competitions,
        "experience": experience,
        "leadership": leadership,
    }


async def ensure_profile(user_id: str, display_name: Optional[str] = None) -> dict:
    p = await db.profiles.find_one({"user_id": user_id}, {"_id": 0})
    if p:
        return p
    p = {
        "user_id": user_id,
        "display_name": display_name or "",
        "school_year": "",
        "grade_average": None,
        "curriculum": "",
        "interests": [],
        "target_courses": [],
        "preferred_countries": [],
        "activities": [],
        "budget": None,
        "target_universities": [],
        "reminders_enabled": True,
        "onboarded": False,
        "created_at": now_utc().isoformat(),
    }
    await db.profiles.insert_one(dict(p))
    return p


def enrich_profile(p: dict) -> dict:
    p = clean(p)
    p["profile_strength"] = compute_strength(p)
    p["categories"] = compute_categories(p)
    return p


@api_router.get("/profile")
async def get_profile(user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    return enrich_profile(p)


@api_router.put("/profile")
async def update_profile(inp: ProfileInput, user: dict = Depends(get_current_user)):
    await ensure_profile(user["user_id"], user.get("name"))
    updates = {k: v for k, v in inp.dict().items() if v is not None}
    if updates.get("interests") or updates.get("target_courses"):
        updates["onboarded"] = True
    await db.profiles.update_one({"user_id": user["user_id"]}, {"$set": updates})
    p = await db.profiles.find_one({"user_id": user["user_id"]}, {"_id": 0})
    return enrich_profile(p)


@api_router.get("/meta/chips")
async def get_chips():
    return {"interests": INTEREST_CHIPS, "courses": COURSE_CHIPS, "countries": COUNTRY_CHIPS}


# ----------------------------- Scoring -----------------------------
def match_university(uni: dict, p: dict) -> int:
    score = 62
    if uni.get("country") in (p.get("preferred_countries") or []):
        score += 18
    budget = p.get("budget")
    annual_cost = uni.get("annual_cost")
    if budget and annual_cost is not None:
        total = annual_cost + (uni.get("living_cost") or 0)
        if total <= budget:
            score += 10
        elif total <= budget * 1.25:
            score += 5
    grade = p.get("grade_average") or 0
    score += min(int(grade / 12.5), 8)
    # Universities without verified stats (the vast majority of a full
    # global import) shouldn't be scored as confidently as curated ones.
    if uni.get("ranking") is None and uni.get("acceptance_rate") is None:
        score = min(score, 75)
    return min(score, 98)


def match_opportunity(op: dict, p: dict) -> int:
    score = 58
    courses = set(p.get("target_courses") or [])
    interests = set(p.get("interests") or [])
    wanted = courses | interests
    matches = len(set(op.get("tags", [])) & wanted)
    score += matches * 18
    if op.get("remote"):
        score += 6
    return min(score, 99)


def fit_scholarship(sch: dict, p: dict) -> int:
    score = 55
    grade = p.get("grade_average") or 0
    if grade >= sch.get("min_grade", 0):
        score += 15
    elif grade:
        score += 5
    if set(sch.get("countries", [])) & set(p.get("preferred_countries") or []):
        score += 15
    if set(sch.get("course_tags", [])) & set(p.get("target_courses") or []):
        score += 15
    return min(score, 99)


def days_left(deadline: Optional[str]) -> Optional[int]:
    if not deadline:
        return None
    try:
        d = datetime.fromisoformat(deadline).replace(tzinfo=timezone.utc)
        return (d - now_utc()).days
    except Exception:
        return None


# ----------------------------- Universities -----------------------------
@api_router.get("/universities")
async def list_universities(q: str = "", country: str = "", user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))

    pool = UNIVERSITIES
    if q:
        needle = q.strip().lower()
        pool = [
            u for u in pool
            if needle in u["name"].lower()
            or needle in (u.get("country") or "").lower()
            or any(needle in s.lower() for s in (u.get("strengths") or []))
        ]
    if country:
        pool = [u for u in pool if (u.get("country") or "").lower() == country.strip().lower()]

    scored = [{**u, "match_score": match_university(u, p)} for u in pool]
    scored.sort(key=lambda x: x["match_score"], reverse=True)

    # Without a search term, don't ship the entire global list — return the
    # curated/high-signal set. With a search term, cap at a sane page size.
    if not q and not country:
        return scored[:60]
    return scored[:200]


@api_router.get("/universities/{uni_id}")
async def get_university(uni_id: str, user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    u = next((x for x in UNIVERSITIES if x["id"] == uni_id), None)
    if not u:
        raise HTTPException(status_code=404, detail="University not found")
    item = {**u, "match_score": match_university(u, p)}
    item["course_list"] = [c for c in COURSES if c["university_id"] == uni_id]
    return item


@api_router.get("/courses/{course_id}")
async def get_course(course_id: str, user: dict = Depends(get_current_user)):
    c = next((x for x in COURSES if x["id"] == course_id), None)
    if not c:
        raise HTTPException(status_code=404, detail="Course not found")
    item = dict(c)
    item["university"] = next((x for x in UNIVERSITIES if x["id"] == c["university_id"]), None)
    return item


# ----------------------------- Opportunities -----------------------------
@api_router.get("/opportunities")
async def list_opportunities(user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    out = [{**o, "relevance_score": match_opportunity(o, p), "days_left": days_left(o.get("deadline"))} for o in OPPORTUNITIES]
    out.sort(key=lambda x: x["relevance_score"], reverse=True)
    return out


@api_router.get("/opportunities/{op_id}")
async def get_opportunity(op_id: str, user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    o = next((x for x in OPPORTUNITIES if x["id"] == op_id), None)
    if not o:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    return {**o, "relevance_score": match_opportunity(o, p), "days_left": days_left(o.get("deadline"))}


# ----------------------------- Scholarships -----------------------------
@api_router.get("/scholarships")
async def list_scholarships(user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    out = [{**s, "fit_score": fit_scholarship(s, p), "days_left": days_left(s.get("deadline"))} for s in SCHOLARSHIPS]
    out.sort(key=lambda x: x["fit_score"], reverse=True)
    return out


# ----------------------------- Saved items -----------------------------
@api_router.get("/saved")
async def list_saved(user: dict = Depends(get_current_user)):
    return await db.saved_items.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(500)


@api_router.post("/saved")
async def add_saved(inp: SavedInput, user: dict = Depends(get_current_user)):
    existing = await db.saved_items.find_one({"user_id": user["user_id"], "item_type": inp.item_type, "item_id": inp.item_id}, {"_id": 0})
    if existing:
        return existing
    rec = {"id": new_id("sv_"), "user_id": user["user_id"], "item_type": inp.item_type, "item_id": inp.item_id, "created_at": now_utc().isoformat()}
    await db.saved_items.insert_one(dict(rec))
    return rec


@api_router.delete("/saved/{item_id}")
async def remove_saved(item_id: str, user: dict = Depends(get_current_user)):
    await db.saved_items.delete_one({"user_id": user["user_id"], "item_id": item_id})
    return {"ok": True}


# ----------------------------- Applications -----------------------------
@api_router.get("/applications")
async def list_applications(user: dict = Depends(get_current_user)):
    apps = await db.applications.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(500)
    for a in apps:
        a["days_left"] = days_left(a.get("deadline"))
    apps.sort(key=lambda x: x.get("deadline") or "9999")
    return apps


@api_router.post("/applications")
async def add_application(inp: ApplicationInput, user: dict = Depends(get_current_user)):
    rec = {
        "id": new_id("app_"), "user_id": user["user_id"],
        "title": inp.title, "item_type": inp.item_type, "item_id": inp.item_id,
        "deadline": inp.deadline, "next_step": inp.next_step, "status": inp.status,
        "created_at": now_utc().isoformat(),
    }
    await db.applications.insert_one(dict(rec))
    rec["days_left"] = days_left(rec.get("deadline"))
    return rec


@api_router.put("/applications/{app_id}")
async def update_application(app_id: str, inp: ApplicationUpdate, user: dict = Depends(get_current_user)):
    updates = {k: v for k, v in inp.dict().items() if v is not None}
    await db.applications.update_one({"id": app_id, "user_id": user["user_id"]}, {"$set": updates})
    a = await db.applications.find_one({"id": app_id, "user_id": user["user_id"]}, {"_id": 0})
    if not a:
        raise HTTPException(status_code=404, detail="Application not found")
    a["days_left"] = days_left(a.get("deadline"))
    return a


@api_router.delete("/applications/{app_id}")
async def delete_application(app_id: str, user: dict = Depends(get_current_user)):
    await db.applications.delete_one({"id": app_id, "user_id": user["user_id"]})
    return {"ok": True}


# ----------------------------- Notifications -----------------------------
@api_router.get("/notifications")
async def list_notifications(user: dict = Depends(get_current_user)):
    notes = await db.notifications.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(200)
    apps = await db.applications.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(200)
    generated = []
    for a in apps:
        dl = days_left(a.get("deadline"))
        if dl is not None and 0 <= dl <= 14:
            nid = f"note_dl_{a['id']}"
            if not any(n["id"] == nid for n in notes):
                generated.append({
                    "id": nid, "user_id": user["user_id"],
                    "title": f"Deadline approaching: {a['title']}",
                    "body": f"{dl} days left to submit.", "read": False,
                    "created_at": now_utc().isoformat(),
                })
    if generated:
        await db.notifications.insert_many([dict(g) for g in generated])
        notes = generated + notes
    notes.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return notes


@api_router.put("/notifications/{note_id}/read")
async def read_notification(note_id: str, user: dict = Depends(get_current_user)):
    await db.notifications.update_one({"id": note_id, "user_id": user["user_id"]}, {"$set": {"read": True}})
    return {"ok": True}


# ----------------------------- Timeline -----------------------------
@api_router.get("/timeline")
async def timeline(user: dict = Depends(get_current_user)):
    events = []
    apps = await db.applications.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(200)
    for a in apps:
        if a.get("deadline"):
            events.append({"kind": "application", "title": a["title"], "deadline": a["deadline"], "days_left": days_left(a["deadline"]), "status": a.get("status")})
    saved = await db.saved_items.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(500)
    saved_ops = {s["item_id"] for s in saved if s["item_type"] == "opportunity"}
    for o in OPPORTUNITIES:
        if o["id"] in saved_ops:
            events.append({"kind": "opportunity", "title": o["title"], "deadline": o["deadline"], "days_left": days_left(o["deadline"]), "type": o["type"]})
    events = [e for e in events if e.get("deadline")]
    events.sort(key=lambda x: x["deadline"])
    return events


# ----------------------------- Dashboard -----------------------------
@api_router.get("/dashboard")
async def dashboard(user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    ep = enrich_profile(dict(p))
    unis = sorted([{**u, "match_score": match_university(u, p)} for u in UNIVERSITIES], key=lambda x: x["match_score"], reverse=True)[:3]
    ops = sorted([{**o, "relevance_score": match_opportunity(o, p), "days_left": days_left(o["deadline"])} for o in OPPORTUNITIES], key=lambda x: x["relevance_score"], reverse=True)[:5]

    apps = await db.applications.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(200)
    upcoming = []
    for a in apps:
        dl = days_left(a.get("deadline"))
        if a.get("deadline") and dl is not None and dl >= 0:
            upcoming.append({"title": a["title"], "deadline": a["deadline"], "days_left": dl})
    upcoming.sort(key=lambda x: x["deadline"])
    next_deadline = upcoming[0] if upcoming else None

    cats = ep["categories"]
    weakest = min(cats, key=cats.get)
    next_step_map = {
        "academics": "Focus on lifting your grade average this term",
        "projects": "Start a personal project to show initiative",
        "competitions": "Apply to a competition or hackathon",
        "experience": "Find an internship or research program",
        "leadership": "Take a leadership role in a club or team",
    }
    return {
        "profile": ep,
        "goal": {
            "courses": p.get("target_courses") or [],
            "universities": [u["short_name"] for u in unis],
        },
        "university_matches": unis,
        "opportunities": ops,
        "next_deadline": next_deadline,
        "next_best_step": next_step_map.get(weakest, "Explore new opportunities"),
    }


# ----------------------------- AI (Claude Sonnet 4.6) -----------------------------
async def run_llm(system: str, prompt: str, session_id: str) -> str:
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    chat = LlmChat(api_key=EMERGENT_LLM_KEY, session_id=session_id, system_message=system).with_model("anthropic", "claude-sonnet-4-6")
    resp = await chat.send_message(UserMessage(text=prompt))
    return resp if isinstance(resp, str) else str(resp)


def profile_summary_text(p: dict) -> str:
    return (
        f"Grade average: {p.get('grade_average') or 'n/a'}. Curriculum: {p.get('curriculum') or 'n/a'}. "
        f"Interests: {', '.join(p.get('interests') or []) or 'n/a'}. "
        f"Target courses: {', '.join(p.get('target_courses') or []) or 'n/a'}. "
        f"Preferred countries: {', '.join(p.get('preferred_countries') or []) or 'n/a'}. "
        f"Activities: {', '.join(p.get('activities') or []) or 'none listed'}."
    )


@api_router.post("/opportunities/{op_id}/explain")
async def explain_opportunity(op_id: str, user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    o = next((x for x in OPPORTUNITIES if x["id"] == op_id), None)
    if not o:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    system = "You are Ryze, a warm, sharp university-admissions mentor for high-school students. Be specific and encouraging. Never use markdown, headings, or bullet points."
    prompt = (
        f"Student profile: {profile_summary_text(p)}\n\n"
        f"Opportunity: {o['title']} ({o['type']}) by {o['organizer']}. "
        f"Skills: {', '.join(o['skills'])}. Tags: {', '.join(o['tags'])}. {o['description']}\n\n"
        "In 2-3 sentences, explain specifically why this opportunity fits THIS student and how it strengthens their university application. Address the student as 'you'."
    )
    try:
        text = await run_llm(system, prompt, f"explain_{user['user_id']}_{op_id}")
    except Exception as e:
        logger.error(f"LLM explain error: {e}")
        text = (
            f"This {o['type'].lower()} lines up with your interest in {', '.join(o['tags'][:2])} and lets you "
            f"demonstrate {', '.join(o['skills'][:2])} — exactly the kind of experience top universities look for."
        )
    return {"explanation": text}


@api_router.get("/insights")
async def insights(user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    ep = enrich_profile(dict(p))
    cats = ep["categories"]
    system = "You are Ryze, a warm, sharp university-admissions mentor for high-school students. Return plain text only — no markdown, no headings. Write 3 short, concrete suggestions each on its own line starting with a dash."
    prompt = (
        f"Student profile: {profile_summary_text(p)}\n"
        f"Profile strength: {ep['profile_strength']}/100. "
        f"Category scores (0-100): Academics {cats['academics']}, Projects {cats['projects']}, "
        f"Competitions {cats['competitions']}, Experience {cats['experience']}, Leadership {cats['leadership']}.\n\n"
        "Give 3 specific, actionable suggestions to improve this student's university application, prioritising the weakest areas."
    )
    try:
        text = await run_llm(system, prompt, f"insights_{user['user_id']}")
        suggestions = [s.strip("-• ").strip() for s in text.split("\n") if s.strip("-• ").strip()][:5]
    except Exception as e:
        logger.error(f"LLM insights error: {e}")
        weakest = sorted(cats, key=cats.get)[:2]
        tips = {
            "academics": "Aim to raise your grade average — it's the biggest single admissions factor.",
            "projects": "Build one portfolio project that shows initiative in your target field.",
            "competitions": "Enter a competition or hackathon to prove your skills under pressure.",
            "experience": "Secure an internship or research placement for real-world experience.",
            "leadership": "Take on a leadership role in a club, team, or community project.",
        }
        suggestions = [tips[w] for w in weakest] + ["Save 2-3 opportunities and start tracking their deadlines."]
    return {"strength": ep["profile_strength"], "categories": cats, "suggestions": suggestions}


@api_router.get("/university-fit/{uni_id}")
async def university_fit(uni_id: str, user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    u = next((x for x in UNIVERSITIES if x["id"] == uni_id), None)
    if not u:
        raise HTTPException(status_code=404, detail="University not found")
    system = "You are Ryze, a warm, sharp university-admissions mentor. Plain text only, no markdown. 2-3 sentences."
    ranking_line = f"World rank {u['ranking']}. " if u.get("ranking") is not None else ""
    strengths_line = f"Strengths: {', '.join(u['strengths'])}. " if u.get("strengths") else ""
    summary_line = u.get("summary") or ""
    location = f"{u.get('city')}, {u['country']}" if u.get("city") else u["country"]
    data_note = "" if u.get("ranking") is not None else " (Note: we don't have verified ranking/stats for this university yet — speak generally about fit based on location and the student's profile, don't invent specifics.)"
    prompt = (
        f"Student profile: {profile_summary_text(p)}\n\n"
        f"University: {u['name']} in {location}. {ranking_line}"
        f"{strengths_line}{summary_line}{data_note}\n\n"
        f"Explain in 2-3 sentences why this university is a {match_university(u, p)}% match for THIS student. Address them as 'you'."
    )
    try:
        text = await run_llm(system, prompt, f"fit_{user['user_id']}_{uni_id}")
    except Exception as e:
        logger.error(f"LLM fit error: {e}")
        if u.get("strengths"):
            text = f"{u['short_name']} is strong in {', '.join(u['strengths'][:2])}, which aligns with your goals, and its location matches your preferences."
        else:
            text = f"{u['short_name']} is located in {u['country']}, which fits your preferences — we don't have full verified stats for this university yet, so worth checking its official site for admissions details."
    return {"explanation": text}


def roadmap_progress(steps: list) -> dict:
    total = len(steps)
    done = sum(1 for s in steps if s.get("done"))
    pct = int((done / total) * 100) if total else 0
    return {"done": done, "total": total, "percent": pct}


@api_router.get("/roadmap")
async def roadmap(regenerate: bool = False, user: dict = Depends(get_current_user)):
    p = await ensure_profile(user["user_id"], user.get("name"))
    existing = await db.roadmaps.find_one({"user_id": user["user_id"]}, {"_id": 0})
    if existing and not regenerate:
        ep = enrich_profile(dict(p))
        return {"strength": ep["profile_strength"], "steps": existing["steps"], "progress": roadmap_progress(existing["steps"])}

    ep = enrich_profile(dict(p))
    cats = ep["categories"]
    weakest = sorted(cats, key=cats.get)
    system = (
        "You are Ryze, an elite university-admissions strategist. Build a concrete, personalised "
        "application roadmap for this high-school student. Return ONLY steps, one per line, each formatted EXACTLY as: "
        "Title :: Timeframe :: One-sentence action. No markdown, no numbering, no extra text. Produce 6 steps ordered by priority."
    )
    prompt = (
        f"Student profile: {profile_summary_text(p)}\n"
        f"Profile strength: {ep['profile_strength']}/100. Weakest areas: {', '.join(weakest[:2])}.\n"
        f"Target courses: {', '.join(p.get('target_courses') or []) or 'undecided'}. "
        f"Preferred countries: {', '.join(p.get('preferred_countries') or []) or 'open'}.\n"
        "Create 6 steps that move them from exploring to a strong application: profile-building activities, "
        "competitions/internships to pursue, and application milestones. Be specific to their goals."
    )
    steps = []
    try:
        text = await run_llm(system, prompt, f"roadmap_{user['user_id']}_{now_utc().timestamp()}")
        for line in text.split("\n"):
            line = line.strip().lstrip("-•0123456789. ").strip()
            if "::" in line:
                parts = [x.strip() for x in line.split("::")]
                if len(parts) >= 3 and parts[0]:
                    steps.append({"title": parts[0], "timeframe": parts[1], "action": parts[2]})
        steps = steps[:6]
    except Exception as e:
        logger.error(f"LLM roadmap error: {e}")
    if not steps:
        steps = [
            {"title": "Lift your grade average", "timeframe": "This term", "action": "Focus study time on your weakest subjects to raise your GPA."},
            {"title": "Start a portfolio project", "timeframe": "Next 4 weeks", "action": "Build one project in your target field to show initiative."},
            {"title": "Enter a competition", "timeframe": "1-2 months", "action": "Apply to a hackathon or olympiad to prove your skills."},
            {"title": "Secure experience", "timeframe": "This summer", "action": "Find an internship or research program in your field."},
            {"title": "Shortlist universities", "timeframe": "2-3 months", "action": "Finalise your target, match and safety schools."},
            {"title": "Draft your essays", "timeframe": "Before deadlines", "action": "Start personal statements early and get feedback."},
        ]
    # Smart deadlines — stagger target dates so they flow into the timeline & reminders
    for i, s in enumerate(steps):
        s["deadline"] = (now_utc() + timedelta(days=(i + 1) * 21)).date().isoformat()
        s["done"] = False
    await db.roadmaps.update_one(
        {"user_id": user["user_id"]},
        {"$set": {"user_id": user["user_id"], "steps": steps, "created_at": now_utc().isoformat()}},
        upsert=True,
    )
    await db.profiles.update_one({"user_id": user["user_id"]}, {"$set": {"roadmap_done": 0}})
    return {"strength": ep["profile_strength"], "steps": steps, "progress": roadmap_progress(steps)}


@api_router.put("/roadmap/step/{index}/toggle")
async def toggle_roadmap_step(index: int, user: dict = Depends(get_current_user)):
    rm = await db.roadmaps.find_one({"user_id": user["user_id"]}, {"_id": 0})
    if not rm or index < 0 or index >= len(rm["steps"]):
        raise HTTPException(status_code=404, detail="Step not found")
    rm["steps"][index]["done"] = not rm["steps"][index].get("done", False)
    prog = roadmap_progress(rm["steps"])
    await db.roadmaps.update_one({"user_id": user["user_id"]}, {"$set": {"steps": rm["steps"]}})
    await db.profiles.update_one({"user_id": user["user_id"]}, {"$set": {"roadmap_done": prog["done"]}})
    p = await db.profiles.find_one({"user_id": user["user_id"]}, {"_id": 0})
    ep = enrich_profile(dict(p))
    return {"steps": rm["steps"], "progress": prog, "strength": ep["profile_strength"]}


@api_router.post("/roadmap/add-to-tracker")
async def roadmap_to_tracker(user: dict = Depends(get_current_user)):
    rm = await db.roadmaps.find_one({"user_id": user["user_id"]}, {"_id": 0})
    if not rm:
        raise HTTPException(status_code=404, detail="No roadmap yet")
    created = 0
    for s in rm["steps"]:
        exists = await db.applications.find_one({"user_id": user["user_id"], "item_type": "roadmap", "title": s["title"]})
        if exists:
            continue
        rec = {
            "id": new_id("app_"), "user_id": user["user_id"], "title": s["title"],
            "item_type": "roadmap", "item_id": None, "deadline": s.get("deadline"),
            "next_step": s["action"], "status": "Planning", "created_at": now_utc().isoformat(),
        }
        await db.applications.insert_one(dict(rec))
        created += 1
    return {"created": created}


@api_router.get("/")
async def root():
    return {"message": "Ryze API"}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    await db.users.create_index("email", unique=True)
    await db.users.create_index("user_id", unique=True)
    await db.user_sessions.create_index("session_token", unique=True)
    await db.user_sessions.create_index("expires_at", expireAfterSeconds=0)
    logger.info("Ryze API started")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
