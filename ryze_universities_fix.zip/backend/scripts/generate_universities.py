"""
Imports ALL universities worldwide into Ryze's university dataset.

Source: Hipolabs' open, keyless world_universities_and_domains.json
(https://github.com/Hipo/university-domains-list) — ~10,000+ universities,
every country. It only gives name/country/domains/web_pages — no ranking,
acceptance rate, cost, strengths, or images.

This script:
1. Downloads that full dataset.
2. Keeps your existing curated universities (from seed_data.py) exactly as
   they are — their real ranking/cost/strengths/summary/image are preserved.
3. Adds every other university with SAFE DEFAULTS for the fields we don't
   actually have data for (None instead of a fabricated number), so the UI
   can honestly show "Not available" instead of a made-up stat.
4. Writes the result to backend/data/universities.json, which seed_data.py
   now loads from instead of a hardcoded Python list.

Run it with:
    cd backend
    python scripts/generate_universities.py
"""
import json
import re
import sys
import urllib.request
from pathlib import Path

SOURCE_URL = "https://raw.githubusercontent.com/Hipo/university-domains-list/master/world_universities_and_domains.json"
BACKEND_DIR = Path(__file__).resolve().parent.parent
OUTPUT_PATH = BACKEND_DIR / "data" / "universities.json"

# Import your existing curated list (the 8 rich entries with real stats).
sys.path.insert(0, str(BACKEND_DIR))
from seed_data import CURATED_UNIVERSITIES as CURATED  # noqa: E402


def slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug[:60] if slug else "university"


def fetch_source() -> list[dict]:
    print(f"Downloading {SOURCE_URL} ...")
    with urllib.request.urlopen(SOURCE_URL, timeout=30) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    print(f"Fetched {len(data)} universities.")
    return data


def build_dataset() -> list[dict]:
    raw = fetch_source()

    curated_names = {u["name"].strip().lower() for u in CURATED}
    seen_ids = {u["id"] for u in CURATED}
    merged = list(CURATED)  # keep curated entries + their real rich stats untouched

    skipped_dupes = 0
    for entry in raw:
        name = (entry.get("name") or "").strip()
        if not name or name.strip().lower() in curated_names:
            skipped_dupes += 1
            continue

        base_id = slugify(name)
        uid = base_id
        n = 2
        while uid in seen_ids:
            uid = f"{base_id}-{n}"
            n += 1
        seen_ids.add(uid)

        web_pages = entry.get("web_pages") or []

        merged.append({
            "id": uid,
            "name": name,
            "short_name": name,
            "country": entry.get("country") or "Unknown",
            "city": entry.get("state-province") or "",
            # Fields we don't have real data for — None, not fabricated.
            # The UI should render these as "Not available" rather than 0/blank.
            "ranking": None,
            "acceptance_rate": None,
            "annual_cost": None,
            "currency": "USD",
            "image": None,
            "logo": f"https://logo.clearbit.com/{entry['domains'][0]}" if entry.get("domains") else None,
            "strengths": [],
            "summary": "",
            "living_cost": None,
            "scholarships_available": 0,
            "website": web_pages[0] if web_pages else None,
            "verified_data": False,  # curated entries don't have this key -> defaults to "verified" in practice
        })

    print(f"Skipped {skipped_dupes} duplicates already in your curated list.")
    print(f"Final dataset: {len(merged)} universities ({len(CURATED)} curated with full stats, {len(merged) - len(CURATED)} basic).")
    return merged


def main():
    dataset = build_dataset()
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(dataset, f, ensure_ascii=False, indent=2)
    print(f"Wrote {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
