"""Seed data for Ryze — realistic sample universities, courses, opportunities, scholarships.
Users can replace this with real data later. IDs are stable strings so relations hold."""
import json
from pathlib import Path

# These 8 have real, verified stats (ranking/acceptance rate/cost/strengths/summary).
# Kept as the source of truth for that rich data — the full global import in
# data/universities.json preserves these exactly and adds ~10,000 more with
# safe defaults for the fields we don't have real data for.
CURATED_UNIVERSITIES = [
    {
        "id": "nus",
        "name": "National University of Singapore",
        "short_name": "NUS",
        "country": "Singapore",
        "city": "Singapore",
        "ranking": 8,
        "acceptance_rate": 5,
        "annual_cost": 30000,
        "currency": "USD",
        "image": "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1200&q=80",
        "logo": "https://logo.clearbit.com/nus.edu.sg",
        "strengths": ["Computer Science", "Engineering", "Business", "AI"],
        "summary": "Asia's leading research university, renowned for computing, engineering and a vibrant global campus.",
        "living_cost": 12000,
        "scholarships_available": 6,
    },
    {
        "id": "hkust",
        "name": "Hong Kong University of Science and Technology",
        "short_name": "HKUST",
        "country": "Hong Kong",
        "city": "Hong Kong",
        "ranking": 30,
        "acceptance_rate": 8,
        "annual_cost": 21000,
        "currency": "USD",
        "image": "https://images.unsplash.com/photo-1591123720164-de1348028b31?auto=format&fit=crop&w=1200&q=80",
        "logo": "https://logo.clearbit.com/hkust.edu.hk",
        "strengths": ["Computer Science", "Engineering", "Data Science", "Robotics"],
        "summary": "A young, ambitious university with world-class engineering and a stunning seaside campus.",
        "living_cost": 13000,
        "scholarships_available": 4,
    },
    {
        "id": "unimelb",
        "name": "University of Melbourne",
        "short_name": "UM",
        "country": "Australia",
        "city": "Melbourne",
        "ranking": 13,
        "acceptance_rate": 70,
        "annual_cost": 33000,
        "currency": "USD",
        "image": "https://images.unsplash.com/photo-1607237138185-eedd9c632b0b?auto=format&fit=crop&w=1200&q=80",
        "logo": "https://logo.clearbit.com/unimelb.edu.au",
        "strengths": ["Computer Science", "Medicine", "Law", "Design"],
        "summary": "Australia's top-ranked university, blending research excellence with a livable, creative city.",
        "living_cost": 18000,
        "scholarships_available": 5,
    },
    {
        "id": "mit",
        "name": "Massachusetts Institute of Technology",
        "short_name": "MIT",
        "country": "United States",
        "city": "Cambridge, MA",
        "ranking": 1,
        "acceptance_rate": 4,
        "annual_cost": 57000,
        "currency": "USD",
        "image": "https://images.unsplash.com/photo-1564981797816-1043664bf78d?auto=format&fit=crop&w=1200&q=80",
        "logo": "https://logo.clearbit.com/mit.edu",
        "strengths": ["Computer Science", "AI", "Engineering", "Physics"],
        "summary": "The world's premier institute for science and technology, driving innovation across every field.",
        "living_cost": 22000,
        "scholarships_available": 8,
    },
    {
        "id": "stanford",
        "name": "Stanford University",
        "short_name": "Stanford",
        "country": "United States",
        "city": "Stanford, CA",
        "ranking": 3,
        "acceptance_rate": 4,
        "annual_cost": 56000,
        "currency": "USD",
        "image": "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=1200&q=80",
        "logo": "https://logo.clearbit.com/stanford.edu",
        "strengths": ["Computer Science", "AI", "Entrepreneurship", "Design"],
        "summary": "Silicon Valley's intellectual home, where cutting-edge research meets startup culture.",
        "living_cost": 24000,
        "scholarships_available": 7,
    },
    {
        "id": "ethz",
        "name": "ETH Zurich",
        "short_name": "ETH",
        "country": "Switzerland",
        "city": "Zurich",
        "ranking": 7,
        "acceptance_rate": 27,
        "annual_cost": 1600,
        "currency": "USD",
        "image": "https://images.unsplash.com/photo-1526129318478-62ed807ebdf9?auto=format&fit=crop&w=1200&q=80",
        "logo": "https://logo.clearbit.com/ethz.ch",
        "strengths": ["Computer Science", "Engineering", "Physics", "Robotics"],
        "summary": "Europe's top technical university, offering elite engineering at remarkably low tuition.",
        "living_cost": 20000,
        "scholarships_available": 3,
    },
    {
        "id": "toronto",
        "name": "University of Toronto",
        "short_name": "UofT",
        "country": "Canada",
        "city": "Toronto",
        "ranking": 21,
        "acceptance_rate": 43,
        "annual_cost": 45000,
        "currency": "USD",
        "image": "https://images.unsplash.com/photo-1569605803663-e9337d901ff9?auto=format&fit=crop&w=1200&q=80",
        "logo": "https://logo.clearbit.com/utoronto.ca",
        "strengths": ["Computer Science", "AI", "Medicine", "Business"],
        "summary": "A research powerhouse and birthplace of deep learning, set in Canada's most dynamic city.",
        "living_cost": 16000,
        "scholarships_available": 5,
    },
    {
        "id": "imperial",
        "name": "Imperial College London",
        "short_name": "Imperial",
        "country": "United Kingdom",
        "city": "London",
        "ranking": 6,
        "acceptance_rate": 14,
        "annual_cost": 40000,
        "currency": "USD",
        "image": "https://images.unsplash.com/photo-1543269865-cbf427effbad?auto=format&fit=crop&w=1200&q=80",
        "logo": "https://logo.clearbit.com/imperial.ac.uk",
        "strengths": ["Engineering", "Computer Science", "Medicine", "Data Science"],
        "summary": "London's science, engineering and medicine specialist with deep industry connections.",
        "living_cost": 21000,
        "scholarships_available": 4,
    },
]

# UNIVERSITIES = the full dataset the app actually uses. Loads the merged
# global file (curated 8 + ~10,000 real universities from every country) if
# it exists. Run `python scripts/generate_universities.py` to create/refresh
# it. Falls back to just the curated 8 if it hasn't been generated yet, so
# the app still runs out of the box.
_DATA_FILE = Path(__file__).resolve().parent / "data" / "universities.json"
if _DATA_FILE.exists():
    with open(_DATA_FILE, "r", encoding="utf-8") as _f:
        UNIVERSITIES = json.load(_f)
else:
    UNIVERSITIES = CURATED_UNIVERSITIES

COURSES = [
    {"id": "nus-cs", "university_id": "nus", "name": "BSc Computer Science", "degree": "BSc", "duration": "4 years", "annual_cost": 30000, "field": "Computer Science", "requirements": ["A-Level AAB or IB 38+", "Strong Mathematics", "Programming portfolio recommended"], "subjects": ["Algorithms", "Machine Learning", "Systems", "Software Engineering"], "careers": ["Software Engineer", "ML Engineer", "Product Manager"]},
    {"id": "nus-eng", "university_id": "nus", "name": "BEng Computer Engineering", "degree": "BEng", "duration": "4 years", "annual_cost": 30000, "field": "Engineering", "requirements": ["A-Level AAB or IB 38+", "Physics & Maths"], "subjects": ["Digital Systems", "Embedded Computing", "Networks"], "careers": ["Hardware Engineer", "Embedded Engineer", "Robotics Engineer"]},
    {"id": "hkust-cs", "university_id": "hkust", "name": "BSc Computer Science", "degree": "BSc", "duration": "4 years", "annual_cost": 21000, "field": "Computer Science", "requirements": ["A-Level ABB or IB 34+", "Mathematics"], "subjects": ["Data Structures", "AI", "Databases", "HCI"], "careers": ["Software Engineer", "Data Scientist", "AI Researcher"]},
    {"id": "unimelb-cs", "university_id": "unimelb", "name": "Bachelor of Science (Computing)", "degree": "BSc", "duration": "3 years", "annual_cost": 33000, "field": "Computer Science", "requirements": ["ATAR 90+ or IB 33+", "Mathematics"], "subjects": ["Programming", "Algorithms", "Cloud Computing"], "careers": ["Software Developer", "Cloud Engineer", "Analyst"]},
    {"id": "mit-cs", "university_id": "mit", "name": "Computer Science & Engineering (6-3)", "degree": "SB", "duration": "4 years", "annual_cost": 57000, "field": "Computer Science", "requirements": ["Exceptional academics", "SAT/ACT optional", "Strong extracurriculars"], "subjects": ["Algorithms", "AI", "Distributed Systems", "Theory"], "careers": ["Software Engineer", "Research Scientist", "Founder"]},
    {"id": "stanford-cs", "university_id": "stanford", "name": "BS Computer Science", "degree": "BS", "duration": "4 years", "annual_cost": 56000, "field": "Computer Science", "requirements": ["Top academics", "Demonstrated impact", "Essays"], "subjects": ["AI", "Systems", "HCI", "Theory"], "careers": ["Software Engineer", "AI Researcher", "Entrepreneur"]},
    {"id": "ethz-cs", "university_id": "ethz", "name": "BSc Computer Science", "degree": "BSc", "duration": "3 years", "annual_cost": 1600, "field": "Computer Science", "requirements": ["Matura / strong Maths", "German proficiency helpful"], "subjects": ["Algorithms", "Systems", "Machine Learning"], "careers": ["Software Engineer", "Researcher", "Data Scientist"]},
    {"id": "toronto-cs", "university_id": "toronto", "name": "BSc Computer Science", "degree": "BSc", "duration": "4 years", "annual_cost": 45000, "field": "Computer Science", "requirements": ["Grade 12 English & Calculus", "Mid-90s average"], "subjects": ["AI", "Software Design", "Theory of Computation"], "careers": ["Software Engineer", "ML Engineer", "Researcher"]},
    {"id": "imperial-cs", "university_id": "imperial", "name": "MEng Computing", "degree": "MEng", "duration": "4 years", "annual_cost": 40000, "field": "Computer Science", "requirements": ["A*A*A incl Maths", "Admissions test (TMUA)"], "subjects": ["Software Engineering", "Networks", "Machine Learning"], "careers": ["Software Engineer", "Quant", "AI Engineer"]},
]

OPPORTUNITIES = [
    {"id": "op-ai-hack", "title": "Global AI Hackathon", "type": "Hackathon", "organizer": "AI Collective", "location": "Remote", "remote": True, "deadline": "2026-08-15", "eligibility": "Ages 14-19", "skills": ["Python", "Machine Learning", "Teamwork"], "tags": ["Computer Science", "AI"], "description": "48-hour hackathon to build an AI product with mentorship from industry engineers.", "url": "https://example.com/ai-hackathon", "image": "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-swe-intern", "title": "Software Engineering Summer Internship", "type": "Internship", "organizer": "TechStart Labs", "location": "Singapore", "remote": False, "deadline": "2026-07-30", "eligibility": "Ages 16+", "skills": ["Programming", "Git", "Problem Solving"], "tags": ["Computer Science", "Engineering"], "description": "8-week paid internship building real features on a production codebase.", "url": "https://example.com/swe-intern", "image": "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-ai-research", "title": "AI Research Program for Teens", "type": "Research", "organizer": "University Research Lab", "location": "Remote", "remote": True, "deadline": "2026-09-01", "eligibility": "Ages 15-18", "skills": ["Research", "Python", "Math"], "tags": ["Computer Science", "AI", "Data Science"], "description": "Mentored research producing a publishable paper in machine learning.", "url": "https://example.com/ai-research", "image": "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-robotics", "title": "International Robotics Olympiad", "type": "Competition", "organizer": "Robotics Federation", "location": "Tokyo, Japan", "remote": False, "deadline": "2026-10-10", "eligibility": "Ages 13-19", "skills": ["Robotics", "Engineering", "Coding"], "tags": ["Robotics", "Engineering"], "description": "Design, build and program robots to compete against teams worldwide.", "url": "https://example.com/robotics", "image": "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-summer-cs", "title": "Summer Coding Academy", "type": "Summer Program", "organizer": "CodeCamp", "location": "Remote", "remote": True, "deadline": "2026-06-30", "eligibility": "Ages 14-18", "skills": ["Programming", "Web Development"], "tags": ["Computer Science"], "description": "Intensive 4-week program covering full-stack development and a capstone project.", "url": "https://example.com/summer-cs", "image": "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-climate", "title": "Climate Innovation Challenge", "type": "Competition", "organizer": "GreenFuture", "location": "Remote", "remote": True, "deadline": "2026-08-20", "eligibility": "Ages 15-19", "skills": ["Sustainability", "Design", "Data"], "tags": ["Climate", "Data Science"], "description": "Pitch a data-driven solution to a real climate problem for a chance at funding.", "url": "https://example.com/climate", "image": "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-volunteer-code", "title": "Code Mentor Volunteer Program", "type": "Volunteering", "organizer": "TeachCode", "location": "Local / Remote", "remote": True, "deadline": "2026-12-01", "eligibility": "Ages 16+", "skills": ["Teaching", "Leadership", "Programming"], "tags": ["Computer Science", "Leadership"], "description": "Teach coding basics to younger students and build leadership experience.", "url": "https://example.com/volunteer", "image": "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-math-olympiad", "title": "International Mathematics Olympiad", "type": "Competition", "organizer": "IMO Committee", "location": "Varies", "remote": False, "deadline": "2026-11-15", "eligibility": "Under 20, pre-university", "skills": ["Mathematics", "Problem Solving"], "tags": ["Mathematics", "Computer Science"], "description": "The world's most prestigious mathematics competition for pre-university students.", "url": "https://example.com/imo", "image": "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-startup", "title": "Youth Startup Accelerator", "type": "Project", "organizer": "FoundersHub", "location": "Remote", "remote": True, "deadline": "2026-09-20", "eligibility": "Ages 15-19", "skills": ["Entrepreneurship", "Product", "Leadership"], "tags": ["Entrepreneurship", "Design", "Leadership"], "description": "Turn your idea into a real product with mentorship, resources and a demo day.", "url": "https://example.com/startup", "image": "https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=800&q=80"},
    {"id": "op-design", "title": "Global Design Thinking Challenge", "type": "Competition", "organizer": "DesignForward", "location": "Remote", "remote": True, "deadline": "2026-07-15", "eligibility": "Ages 14-19", "skills": ["Design", "Creativity", "Prototyping"], "tags": ["Design", "Entrepreneurship"], "description": "Solve a human-centered design problem and present to a panel of designers.", "url": "https://example.com/design", "image": "https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&w=800&q=80"},
]

SCHOLARSHIPS = [
    {"id": "sch-chevening", "name": "Chevening Scholarship", "provider": "UK Government", "amount": "Full tuition + living", "type": "Full", "based_on": "Merit", "level": "Postgraduate", "countries": ["United Kingdom"], "course_tags": ["Computer Science", "Engineering", "Data Science"], "min_grade": 80, "deadline": "2026-11-05", "url": "https://www.chevening.org"},
    {"id": "sch-gates", "name": "Gates Cambridge Scholarship", "provider": "University of Cambridge", "amount": "Full cost", "type": "Full", "based_on": "Merit", "level": "Postgraduate", "countries": ["United Kingdom"], "course_tags": ["Computer Science", "AI", "Engineering"], "min_grade": 85, "deadline": "2026-10-15", "url": "https://www.gatescambridge.org"},
    {"id": "sch-knight", "name": "Knight-Hennessy Scholars", "provider": "Stanford University", "amount": "Full funding", "type": "Full", "based_on": "Merit", "level": "Graduate", "countries": ["United States"], "course_tags": ["Computer Science", "AI", "Entrepreneurship"], "min_grade": 85, "deadline": "2026-10-09", "url": "https://knight-hennessy.stanford.edu"},
    {"id": "sch-pearson", "name": "Lester B. Pearson Scholarship", "provider": "University of Toronto", "amount": "Full tuition + residence", "type": "Full", "based_on": "Merit", "level": "Undergraduate", "countries": ["Canada"], "course_tags": ["Computer Science", "Engineering", "Medicine"], "min_grade": 90, "deadline": "2026-11-30", "url": "https://future.utoronto.ca/pearson"},
    {"id": "sch-daad", "name": "DAAD Scholarship", "provider": "German Academic Exchange", "amount": "Monthly stipend + tuition", "type": "Stipend", "based_on": "Need", "level": "Undergraduate", "countries": ["Switzerland", "United Kingdom"], "course_tags": ["Engineering", "Computer Science"], "min_grade": 75, "deadline": "2026-09-30", "url": "https://www.daad.de"},
    {"id": "sch-mbzuai", "name": "MBZUAI Merit Award", "provider": "MBZUAI", "amount": "Full tuition + stipend", "type": "Full", "based_on": "Merit", "level": "Graduate", "countries": ["United States", "Singapore"], "course_tags": ["AI", "Computer Science", "Data Science"], "min_grade": 80, "deadline": "2026-12-15", "url": "https://mbzuai.ac.ae"},
    {"id": "sch-asean", "name": "ASEAN Undergraduate Scholarship", "provider": "NUS", "amount": "Partial tuition", "type": "Partial", "based_on": "Merit", "level": "Undergraduate", "countries": ["Singapore"], "course_tags": ["Computer Science", "Engineering", "Business"], "min_grade": 82, "deadline": "2026-08-31", "url": "https://nus.edu.sg/oam"},
    {"id": "sch-melb", "name": "Melbourne International Excellence", "provider": "University of Melbourne", "amount": "Variable up to full", "type": "Variable", "based_on": "Merit", "level": "Undergraduate", "countries": ["Australia"], "course_tags": ["Computer Science", "Design", "Medicine"], "min_grade": 85, "deadline": "2026-10-31", "url": "https://scholarships.unimelb.edu.au"},
]

INTEREST_CHIPS = [
    "Robotics", "Climate", "AI", "Design", "Mathematics", "Data Science",
    "Entrepreneurship", "Medicine", "Physics", "Writing", "Music", "Sports",
    "Leadership", "Finance", "Biology", "Space",
]

COURSE_CHIPS = [
    "Computer Science", "Engineering", "Medicine", "Business", "Data Science",
    "Design", "Mathematics", "Physics", "Law", "Economics",
]

COUNTRY_CHIPS = [
    "Singapore", "United States", "United Kingdom", "Canada", "Australia",
    "Switzerland", "Hong Kong", "Germany", "Netherlands", "UAE",
]
