import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { colors, spacing, radius, type, shadow, urgencyColor } from "@/src/theme";
import { AppText, ScoreBadge, ProgressBar, IconTile } from "@/src/components/ui";

const CAT_LABELS: Record<string, string> = {
  academics: "Academics",
  projects: "Projects",
  competitions: "Competitions",
  experience: "Experience",
  leadership: "Leadership",
};

export function StrengthBars({ categories, onDark }: { categories: Record<string, number>; onDark?: boolean }) {
  const labelColor = onDark ? "rgba(255,255,255,0.9)" : colors.onSurfaceSecondary;
  const subColor = onDark ? "rgba(255,255,255,0.6)" : colors.muted;
  return (
    <View style={{ gap: spacing.md }}>
      {Object.keys(CAT_LABELS).map((k) => (
        <View key={k}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 6 }}>
            <AppText size={type.base} weight="bold" color={labelColor}>{CAT_LABELS[k]}</AppText>
            <AppText size={type.sm} weight="medium" color={subColor}>{categories[k] >= 80 ? "Strong" : categories[k] >= 60 ? "Good" : "Developing"}</AppText>
          </View>
          <ProgressBar value={categories[k]} color={categories[k] >= 80 ? colors.accent : colors.brandPrimary} track={onDark ? "rgba(255,255,255,0.18)" : colors.surfaceTertiary} height={10} />
        </View>
      ))}
    </View>
  );
}

export function Tag({ label, tone = "lavender" }: { label: string; tone?: "lavender" | "lime" | "blue" | "ink" }) {
  const map = {
    lavender: { bg: colors.brandTertiary, fg: colors.brandPrimary },
    lime: { bg: colors.accentSoft, fg: "#4A6300" },
    blue: { bg: "#E1ECFF", fg: "#2E5AAC" },
    ink: { bg: colors.ink, fg: colors.onInk },
  }[tone];
  return (
    <View style={[styles.tag, { backgroundColor: map.bg }]}>
      <AppText size={type.sm} weight="bold" color={map.fg}>{label}</AppText>
    </View>
  );
}

export function InfoPill({ icon, label }: { icon: any; label: string }) {
  return (
    <View style={styles.infoPill}>
      <Ionicons name={icon} size={14} color={colors.onSurfaceTertiary} />
      <AppText size={type.sm} weight="medium" color={colors.onSurfaceTertiary}>{label}</AppText>
    </View>
  );
}

export function UniversityCard({ uni, onPress, saved, onToggleSave, testID }: { uni: any; onPress: () => void; saved?: boolean; onToggleSave?: () => void; testID?: string }) {
  return (
    <Pressable onPress={onPress} style={styles.uniCard} testID={testID}>
      <View style={styles.uniImageWrap}>
        <Image source={{ uri: uni.image }} style={StyleSheet.absoluteFill as any} contentFit="cover" transition={250} />
        <LinearGradient colors={["transparent", "rgba(20,20,25,0.35)"]} style={StyleSheet.absoluteFill} />
        <View style={styles.badgeFloat}>
          <ScoreBadge score={uni.match_score} label="match" />
        </View>
        {onToggleSave ? (
          <Pressable onPress={onToggleSave} hitSlop={10} style={styles.saveBtn} testID={`${testID}-save`}>
            <Ionicons name={saved ? "bookmark" : "bookmark-outline"} size={18} color={colors.onSurface} />
          </Pressable>
        ) : null}
      </View>
      <View style={styles.uniBody}>
        <View style={styles.logoTile}>
          <Image source={{ uri: uni.logo }} style={{ width: 26, height: 26 }} contentFit="contain" />
        </View>
        <View style={{ flex: 1 }}>
          <AppText size={type.xl} weight="extrabold" numberOfLines={1}>{uni.name}</AppText>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}>
            <Ionicons name="location-outline" size={14} color={colors.muted} />
            <AppText size={type.sm} weight="medium" color={colors.muted}>{uni.city}, {uni.country}</AppText>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={22} color={colors.muted} />
      </View>
    </Pressable>
  );
}

export function UniversityRow({ uni, onPress, testID }: { uni: any; onPress: () => void; testID?: string }) {
  return (
    <Pressable onPress={onPress} style={styles.row} testID={testID}>
      <View style={styles.logoTile}>
        <Image source={{ uri: uni.logo }} style={{ width: 26, height: 26 }} contentFit="contain" />
      </View>
      <View style={{ flex: 1 }}>
        <AppText weight="extrabold" size={type.lg}>{uni.short_name}</AppText>
        <AppText size={type.sm} weight="medium" color={colors.muted} numberOfLines={1}>{uni.country}{uni.ranking != null ? ` · #${uni.ranking}` : ""}</AppText>
      </View>
      <ScoreBadge score={uni.match_score} />
    </Pressable>
  );
}

const OP_ICON: Record<string, keyof typeof Ionicons.glyphMap> = {
  Hackathon: "code-slash",
  Internship: "briefcase",
  Research: "flask",
  Competition: "trophy",
  "Summer Program": "sunny",
  Volunteering: "heart",
  Project: "rocket",
};

export function OpportunityCard({ op, onPress, wide, saved, onToggleSave, testID }: { op: any; onPress: () => void; wide?: boolean; saved?: boolean; onToggleSave?: () => void; testID?: string }) {
  return (
    <Pressable onPress={onPress} style={[styles.opCard, wide && { width: 280 }]} testID={testID}>
      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md }}>
        <Tag label={op.type} />
        {onToggleSave ? (
          <Pressable onPress={onToggleSave} hitSlop={10} style={styles.opSave} testID={`${testID}-save`}>
            <Ionicons name={saved ? "bookmark" : "bookmark-outline"} size={16} color={colors.onSurface} />
          </Pressable>
        ) : null}
      </View>
      <AppText weight="extrabold" size={type.xl} numberOfLines={2}>{op.title}</AppText>
      <AppText size={type.base} weight="medium" color={colors.muted} style={{ marginTop: 2 }} numberOfLines={1}>{op.organizer}</AppText>
      <View style={{ flexDirection: "row", gap: spacing.sm, marginTop: spacing.md, flexWrap: "wrap" }}>
        <InfoPill icon="calendar-outline" label={op.deadline} />
        <InfoPill icon="location-outline" label={op.location} />
      </View>
      <View style={styles.opFooter}>
        <ScoreBadge score={op.relevance_score} label="relevant" />
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Ionicons name="sparkles" size={14} color={colors.brandPrimary} />
          <AppText weight="bold" size={type.base} color={colors.brandPrimary}>Why me?</AppText>
        </View>
      </View>
    </Pressable>
  );
}

export function ScholarshipCard({ sch, onPress, testID }: { sch: any; onPress: () => void; testID?: string }) {
  const toneFor = (t: string) => (t === "Full" ? "lime" : t === "Need" ? "blue" : "lavender");
  return (
    <Pressable onPress={onPress} style={styles.opCard} testID={testID}>
      <View style={{ flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", marginBottom: spacing.sm }}>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.xs, flex: 1 }}>
          <Tag label={sch.type} tone={toneFor(sch.type)} />
          <Tag label={sch.based_on} tone="lavender" />
        </View>
        <ScoreBadge score={sch.fit_score} label="fit" tone="ink" />
      </View>
      <AppText weight="extrabold" size={type.xl} numberOfLines={2}>{sch.name}</AppText>
      <AppText size={type.base} weight="medium" color={colors.muted} style={{ marginTop: 2 }}>{sch.provider}</AppText>
      <AppText weight="extrabold" size={type.lg} color={colors.success} style={{ marginTop: spacing.md }}>{sch.amount}</AppText>
      <View style={styles.opFooter}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Ionicons name="calendar-outline" size={14} color={urgencyColor(sch.days_left)} />
          <AppText weight="bold" size={type.sm} color={urgencyColor(sch.days_left)}>
            {sch.days_left != null && sch.days_left >= 0 ? `${sch.days_left}d left` : "Closed"}
          </AppText>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <AppText weight="bold" size={type.base} color={colors.brandPrimary}>Apply</AppText>
          <Ionicons name="open-outline" size={14} color={colors.brandPrimary} />
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  uniCard: { backgroundColor: colors.surfaceSecondary, borderRadius: radius.lg, overflow: "hidden", ...shadow.card },
  uniImageWrap: { height: 190, justifyContent: "flex-end" },
  badgeFloat: { position: "absolute", bottom: spacing.md, left: spacing.md },
  saveBtn: { position: "absolute", top: spacing.md, right: spacing.md, width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.92)", alignItems: "center", justifyContent: "center" },
  uniBody: { flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.lg },
  logoTile: { width: 46, height: 46, borderRadius: radius.sm, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" },
  row: { flexDirection: "row", alignItems: "center", gap: spacing.md, backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.sm },
  opCard: { backgroundColor: colors.surfaceSecondary, borderRadius: radius.lg, padding: spacing.lg, ...shadow.card },
  opSave: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceTertiary, alignItems: "center", justifyContent: "center" },
  opFooter: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: spacing.lg },
  tag: { borderRadius: radius.pill, paddingHorizontal: spacing.md, paddingVertical: 6 },
  infoPill: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: colors.surfaceTertiary, borderRadius: radius.pill, paddingHorizontal: spacing.md, paddingVertical: 6 },
});
