import React, { useCallback, useEffect, useMemo, useState } from "react";
import { View, StyleSheet, FlatList, Pressable, TextInput } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter, useFocusEffect } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { api } from "@/src/api";
import { useToast } from "@/src/components/Toast";
import { AppText, Loader, EmptyState, Segment } from "@/src/components/ui";
import { UniversityCard } from "@/src/components/cards";
import { BigHeader } from "@/src/components/BigHeader";
import { colors, spacing, radius, type, fonts, shadow } from "@/src/theme";

const FILTERS = ["All", "High match", "Reach", "Saved"] as const;

export default function Universities() {
  const router = useRouter();
  const toast = useToast();
  const insets = useSafeAreaInsets();
  const [unis, setUnis] = useState<any[] | null>(null);
  const [saved, setSaved] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");

  const load = useCallback(async (searchQuery = "") => {
    try {
      const [u, s] = await Promise.all([
        api.get(`/universities${searchQuery ? `?q=${encodeURIComponent(searchQuery)}` : ""}`),
        api.get("/saved"),
      ]);
      setUnis(u);
      setSaved(s.filter((x: any) => x.item_type === "university").map((x: any) => x.item_id));
    } catch {}
  }, []);

  useFocusEffect(useCallback(() => { load(query); }, [load]));

  // Debounced server-side search — searches the full global dataset,
  // not just whatever page is currently loaded.
  useEffect(() => {
    const handle = setTimeout(() => { load(query); }, 350);
    return () => clearTimeout(handle);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  const toggleSave = async (id: string) => {
    const isSaved = saved.includes(id);
    setSaved((prev) => (isSaved ? prev.filter((x) => x !== id) : [...prev, id]));
    try {
      if (isSaved) await api.del(`/saved/${id}`);
      else {
        await api.post("/saved", { item_type: "university", item_id: id });
        toast.show("Saved to shortlist", "success");
      }
    } catch {
      load(query);
    }
  };

  const filtered = useMemo(() => {
    if (!unis) return [];
    let list = unis;
    if (filter === "High match") list = list.filter((u) => u.match_score >= 85);
    // Guard against null acceptance_rate (universities without verified stats) —
    // `null <= 15` is true in JS, which would wrongly include every unranked
    // university here otherwise.
    else if (filter === "Reach") list = list.filter((u) => u.acceptance_rate != null && u.acceptance_rate <= 15);
    else if (filter === "Saved") list = list.filter((u) => saved.includes(u.id));
    return list;
  }, [unis, filter, saved]);

  if (!unis) return <View style={{ flex: 1, backgroundColor: colors.surface }}><Loader /></View>;

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <BigHeader eyebrow="University discovery" title="Find your kind of place." />
      <View style={styles.controls}>
        <View style={styles.searchBox}>
          <Ionicons name="search" size={18} color={colors.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="Search universities, countries…"
            placeholderTextColor={colors.muted}
            style={styles.searchInput}
            testID="uni-search-input"
          />
          {query ? (
            <Pressable onPress={() => setQuery("")} hitSlop={8}>
              <Ionicons name="close-circle" size={18} color={colors.muted} />
            </Pressable>
          ) : null}
        </View>
        <FlatList
          data={FILTERS}
          keyExtractor={(x) => x}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ gap: spacing.sm, paddingVertical: spacing.md }}
          renderItem={({ item }) => (
            <Segment label={item} active={filter === item} onPress={() => setFilter(item)} testID={`uni-filter-${item}`} />
          )}
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(u) => u.id}
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 110, gap: spacing.lg }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={<EmptyState icon="school-outline" title="No universities found" body="Try expanding your search or filters." />}
        renderItem={({ item }) => (
          <UniversityCard uni={item} saved={saved.includes(item.id)} onToggleSave={() => toggleSave(item.id)} onPress={() => router.push(`/universities/${item.id}`)} testID={`uni-card-${item.id}`} />
        )}
      />

      <Pressable onPress={() => router.push("/compare")} style={[styles.fab, { bottom: insets.bottom + 94 }]} testID="uni-compare-fab">
        <Ionicons name="git-compare" size={20} color={colors.onBrandPrimary} />
        <AppText weight="semibold" color={colors.onBrandPrimary}>Compare</AppText>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  controls: { paddingHorizontal: spacing.lg, backgroundColor: colors.surface },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    backgroundColor: colors.surfaceSecondary,
    borderRadius: radius.md,
    paddingHorizontal: spacing.lg,
    height: 52,
  },
  searchInput: { flex: 1, fontFamily: fonts.regular, fontSize: type.lg, color: colors.onSurface },
  seg: { height: 36, borderRadius: radius.pill, paddingHorizontal: spacing.lg, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  segActive: { backgroundColor: colors.brandPrimary },
  segIdle: { backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border },
  fab: {
    position: "absolute",
    right: spacing.lg,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.sm,
    backgroundColor: colors.brandPrimary,
    paddingHorizontal: spacing.lg,
    height: 52,
    borderRadius: radius.pill,
    ...shadow.float,
  },
});
