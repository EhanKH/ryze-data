import React, { useCallback, useEffect, useState } from "react";
import { View, StyleSheet, ScrollView, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { api } from "@/src/api";
import { useToast } from "@/src/components/Toast";
import { AppText, Button, Card, Loader, ScoreBadge, IconTile } from "@/src/components/ui";
import { Tag } from "@/src/components/cards";
import { colors, spacing, radius, type } from "@/src/theme";

export default function UniversityDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const toast = useToast();
  const insets = useSafeAreaInsets();
  const [uni, setUni] = useState<any>(null);
  const [saved, setSaved] = useState(false);
  const [fit, setFit] = useState<string>("");
  const [loadingFit, setLoadingFit] = useState(true);

  const load = useCallback(async () => {
    try {
      const [u, s] = await Promise.all([api.get(`/universities/${id}`), api.get("/saved")]);
      setUni(u);
      setSaved(s.some((x: any) => x.item_type === "university" && x.item_id === id));
    } catch {}
  }, [id]);

  useEffect(() => {
    load();
    setLoadingFit(true);
    api.get(`/university-fit/${id}`).then((r) => setFit(r.explanation)).catch(() => setFit("")).finally(() => setLoadingFit(false));
  }, [id, load]);

  const toggleSave = async () => {
    setSaved((v) => !v);
    try {
      if (saved) await api.del(`/saved/${id}`);
      else { await api.post("/saved", { item_type: "university", item_id: id }); toast.show("Saved to shortlist", "success"); }
    } catch { load(); }
  };

  const track = async () => {
    try {
      await api.post("/applications", { title: `${uni.short_name} application`, item_type: "university", item_id: id, next_step: "Review admission requirements", status: "Planning" });
      toast.show("Added to tracker", "success");
    } catch (e: any) { toast.show(e.message || "Failed", "error"); }
  };

  if (!uni) return <View style={{ flex: 1, backgroundColor: colors.surface }}><Loader /></View>;

  const hasVerifiedStats = uni.annual_cost != null;
  const total = hasVerifiedStats ? uni.annual_cost + (uni.living_cost || 0) : null;

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }} showsVerticalScrollIndicator={false}>
        <View style={{ height: 280 }}>
          <Image source={{ uri: uni.image || "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=1200&q=80" }} style={StyleSheet.absoluteFill as any} contentFit="cover" transition={250} />
          <LinearGradient colors={["rgba(24,26,25,0.35)", "transparent", "rgba(24,26,25,0.9)"]} style={StyleSheet.absoluteFill} />
          <View style={[styles.topBar, { paddingTop: insets.top + spacing.sm }]}>
            <Pressable onPress={() => router.back()} style={styles.circleBtn} testID="unidetail-back">
              <Ionicons name="chevron-back" size={22} color="#FFFFFF" />
            </Pressable>
            <Pressable onPress={toggleSave} style={styles.circleBtn} testID="unidetail-save">
              <Ionicons name={saved ? "bookmark" : "bookmark-outline"} size={20} color="#FFFFFF" />
            </Pressable>
          </View>
          <View style={styles.heroText}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <View style={styles.logoBox}><Image source={{ uri: uni.logo }} style={{ width: 34, height: 34 }} contentFit="contain" /></View>
              <ScoreBadge score={uni.match_score} label="match" />
            </View>
            <AppText size={type.display} weight="semibold" color="#FFFFFF" style={{ marginTop: spacing.md }}>{uni.short_name}</AppText>
            <AppText color="rgba(255,255,255,0.9)">{uni.name}</AppText>
            <AppText color="rgba(255,255,255,0.8)" size={type.sm} style={{ marginTop: 2 }}>{uni.city}{uni.city ? ", " : ""}{uni.country}{uni.ranking != null ? ` · #${uni.ranking} worldwide` : ""}</AppText>
          </View>
        </View>

        <View style={{ padding: spacing.lg }}>
          <View style={styles.statsRow}>
            <Stat icon="ribbon-outline" label="Acceptance" value={uni.acceptance_rate != null ? `${uni.acceptance_rate}%` : "—"} />
            <Stat icon="cash-outline" label="Tuition/yr" value={uni.annual_cost != null ? `$${(uni.annual_cost / 1000).toFixed(0)}k` : "—"} />
            <Stat icon="gift-outline" label="Awards" value={uni.scholarships_available ? String(uni.scholarships_available) : "—"} />
          </View>

          <Card style={styles.aiCard}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm, marginBottom: spacing.sm }}>
              <Ionicons name="sparkles" size={16} color={colors.brandPrimary} />
              <AppText weight="semibold" color={colors.brandPrimary}>Why it's a {uni.match_score}% match</AppText>
            </View>
            {loadingFit ? <AppText color={colors.muted}>Analysing your fit…</AppText> : <AppText style={{ color: colors.onSurfaceSecondary }}>{fit}</AppText>}
          </Card>

          <AppText weight="semibold" size={type.lg} style={{ marginBottom: spacing.sm }}>About</AppText>
          <AppText style={{ color: colors.onSurfaceSecondary, marginBottom: spacing.lg }}>
            {uni.summary || "Detailed profile not available yet for this university — we still cover its name, country and location."}
          </AppText>

          {uni.strengths?.length > 0 && (
            <>
              <AppText weight="semibold" size={type.lg} style={{ marginBottom: spacing.sm }}>Known for</AppText>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm, marginBottom: spacing.xl }}>
                {uni.strengths.map((s: string) => <Tag key={s} label={s} />)}
              </View>
            </>
          )}

          {hasVerifiedStats ? (
            <Card style={{ marginBottom: spacing.xl }}>
              <AppText weight="semibold" size={type.lg} style={{ marginBottom: spacing.md }}>Estimated yearly cost</AppText>
              <CostRow label="Tuition" value={`$${uni.annual_cost.toLocaleString()}`} />
              <CostRow label="Living costs" value={`$${(uni.living_cost || 0).toLocaleString()}`} />
              <View style={styles.costTotal}>
                <AppText weight="semibold" size={type.lg}>Total</AppText>
                <AppText weight="semibold" size={type.lg} color={colors.brandPrimary}>${total.toLocaleString()}</AppText>
              </View>
              {uni.scholarships_available ? (
                <AppText size={type.sm} color={colors.muted} style={{ marginTop: spacing.sm }}>{uni.scholarships_available} scholarships potentially available</AppText>
              ) : null}
            </Card>
          ) : (
            <Card style={{ marginBottom: spacing.xl }}>
              <AppText weight="semibold" size={type.lg} style={{ marginBottom: spacing.sm }}>Cost data not available</AppText>
              <AppText size={type.sm} color={colors.muted}>We don't have verified tuition figures for this university yet. Check its official website for current costs.</AppText>
            </Card>
          )}

          <AppText weight="semibold" size={type.lg} style={{ marginBottom: spacing.md }}>Courses</AppText>
          {uni.course_list?.map((c: any) => (
            <Pressable key={c.id} onPress={() => router.push(`/courses/${c.id}`)} style={styles.courseRow} testID={`course-${c.id}`}>
              <IconTile icon="book" />
              <View style={{ flex: 1 }}>
                <AppText weight="semibold">{c.name}</AppText>
                <AppText size={type.sm} color={colors.muted}>{c.degree} · {c.duration}</AppText>
              </View>
              <Ionicons name="chevron-forward" size={20} color={colors.muted} />
            </Pressable>
          ))}
        </View>
      </ScrollView>

      <View style={[styles.stickyBar, { paddingBottom: insets.bottom + spacing.md }]}>
        <Button label={saved ? "Saved" : "Save"} icon={saved ? "bookmark" : "bookmark-outline"} variant="secondary" onPress={toggleSave} style={{ flex: 1 }} testID="unidetail-save-button" />
        <Button label="Track application" icon="add" onPress={track} style={{ flex: 1.4 }} testID="unidetail-track-button" />
      </View>
    </View>
  );
}

function Stat({ icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <View style={styles.stat}>
      <Ionicons name={icon} size={20} color={colors.brandPrimary} />
      <AppText weight="semibold" size={type.lg} style={{ marginTop: spacing.xs }}>{value}</AppText>
      <AppText size={type.sm} color={colors.muted}>{label}</AppText>
    </View>
  );
}

function CostRow({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: spacing.sm }}>
      <AppText color={colors.onSurfaceTertiary}>{label}</AppText>
      <AppText weight="medium">{value}</AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  topBar: { position: "absolute", top: 0, left: 0, right: 0, flexDirection: "row", justifyContent: "space-between", paddingHorizontal: spacing.lg },
  circleBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(0,0,0,0.35)", alignItems: "center", justifyContent: "center" },
  heroText: { position: "absolute", bottom: 0, left: 0, right: 0, padding: spacing.lg },
  logoBox: { width: 48, height: 48, borderRadius: radius.sm, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
  statsRow: { flexDirection: "row", gap: spacing.md, marginBottom: spacing.lg },
  stat: { flex: 1, backgroundColor: colors.surfaceSecondary, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, padding: spacing.md, alignItems: "center" },
  aiCard: { backgroundColor: colors.brandTertiary, borderColor: colors.brandSecondary, marginBottom: spacing.xl },
  courseRow: { flexDirection: "row", alignItems: "center", gap: spacing.md, backgroundColor: colors.surfaceSecondary, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.md, marginBottom: spacing.sm },
  costTotal: { flexDirection: "row", justifyContent: "space-between", borderTopWidth: 1, borderTopColor: colors.divider, paddingTop: spacing.md, marginTop: spacing.xs },
  stickyBar: { position: "absolute", bottom: 0, left: 0, right: 0, flexDirection: "row", gap: spacing.md, padding: spacing.lg, paddingTop: spacing.md, backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.divider },
});
